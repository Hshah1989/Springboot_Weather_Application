package com.umgc.cmsc495.group1springapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Group1SpringAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(Group1SpringAppApplication.class, args);
	}

}
