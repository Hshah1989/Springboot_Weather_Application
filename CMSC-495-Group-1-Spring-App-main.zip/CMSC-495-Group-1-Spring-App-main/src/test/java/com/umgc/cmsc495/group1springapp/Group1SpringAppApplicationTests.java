package com.umgc.cmsc495.group1springapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Group1SpringAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
